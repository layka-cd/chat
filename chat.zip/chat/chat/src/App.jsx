import { useEffect, useRef, useState } from 'react'
import Peer from 'peerjs'

const MAX_PARTICIPANTS = 9 // termasuk diri sendiri

function sanitizeCode(raw) {
  const slug = raw
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
  return slug ? `pc-${slug}` : ''
}

function nowTime() {
  return new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })
}

// Server TURN diperlukan supaya koneksi tetap bisa terbentuk walau salah satu
// pihak ada di jaringan data seluler (CGNAT) yang tidak bisa ditembus STUN saja.
// Daftar gratis di https://dashboard.metered.ca/signup lalu isi VITE_METERED_APP_NAME
// dan VITE_METERED_API_KEY di file .env (lihat README).
async function getIceServers() {
  const appName = import.meta.env.VITE_METERED_APP_NAME
  const apiKey = import.meta.env.VITE_METERED_API_KEY

  if (appName && apiKey) {
    try {
      const controller = new AbortController()
      const abortTimer = setTimeout(() => controller.abort(), 6000) // jangan nge-block lama-lama
      const res = await fetch(
        `https://${appName}.metered.live/api/v1/turn/credentials?apiKey=${apiKey}`,
        { signal: controller.signal }
      )
      clearTimeout(abortTimer)
      if (res.ok) {
        const servers = await res.json()
        if (Array.isArray(servers) && servers.length > 0) return servers
      } else {
        console.error('Metered API respon error:', res.status, await res.text())
      }
    } catch (e) {
      console.error('Gagal ambil kredensial TURN, fallback ke STUN saja:', e)
    }
  }

  // Fallback: STUN saja (cukup untuk jaringan WiFi/LAN biasa, TAPI kemungkinan
  // besar gagal kalau salah satu pihak pakai data seluler)
  return [{ urls: 'stun:stun.l.google.com:19302' }]
}

export default function App() {
  const [screen, setScreen] = useState('home') // home | chat
  const [name, setName] = useState('')
  const [roomCodeInput, setRoomCodeInput] = useState('')
  const [messages, setMessages] = useState([])
  const [messageInput, setMessageInput] = useState('')
  const [status, setStatus] = useState('')
  const [role, setRole] = useState('') // '' | 'host' | 'guest'
  const [members, setMembers] = useState([]) // [{ id, name }]
  const [connected, setConnected] = useState(false)
  const [roomLabel, setRoomLabel] = useState('')
  const [sidebarOpen, setSidebarOpen] = useState(false)

  const peerRef = useRef(null)
  const connsRef = useRef(new Map()) // host: peerId -> { conn, name }
  const hostConnRef = useRef(null) // guest: satu koneksi ke host
  const chatEndRef = useRef(null)
  const timeoutRef = useRef(null)
  const nameRef = useRef('')
  const iceServersRef = useRef(null)

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  useEffect(() => {
    return () => {
      clearTimeout(timeoutRef.current)
      hostConnRef.current?.close()
      connsRef.current.forEach(({ conn }) => conn.close())
      peerRef.current?.destroy()
    }
  }, [])

  useEffect(() => {
    // Tutup koneksi dengan rapi kalau tab ditutup/direfresh paksa, biar ID
    // room nggak "kesangkut" jadi zombie di server PeerJS.
    function handleUnload() {
      hostConnRef.current?.close()
      connsRef.current.forEach(({ conn }) => conn.close())
      peerRef.current?.destroy()
    }
    window.addEventListener('pagehide', handleUnload)
    window.addEventListener('beforeunload', handleUnload)
    return () => {
      window.removeEventListener('pagehide', handleUnload)
      window.removeEventListener('beforeunload', handleUnload)
    }
  }, [])

  function addMessage(msg) {
    setMessages((prev) => [...prev, msg])
  }

  function addSystem(text) {
    addMessage({ from: 'system', text })
  }

  // ---------- HOST ----------
  function currentMembersList() {
    const self = { id: peerRef.current?.id, name: nameRef.current }
    const others = Array.from(connsRef.current.entries()).map(([id, { name }]) => ({
      id,
      name: name || '...',
    }))
    return [self, ...others]
  }

  function broadcastToOthers(excludePeerId, payload) {
    connsRef.current.forEach(({ conn }, peerId) => {
      if (peerId !== excludePeerId) conn.send(payload)
    })
  }

  function broadcastToAll(payload) {
    connsRef.current.forEach(({ conn }) => conn.send(payload))
  }

  function broadcastRoster() {
    const list = currentMembersList()
    setMembers(list)
    broadcastToAll({ type: 'roster', members: list })
  }

  function setupHostConnection(conn) {
    conn.on('open', () => {
      connsRef.current.set(conn.peer, { conn, name: null })
      broadcastRoster()
    })

    conn.on('data', (data) => {
      if (data.type === 'intro') {
        const entry = connsRef.current.get(conn.peer)
        if (entry) entry.name = data.name
        addSystem(`${data.name} bergabung`)
        broadcastToOthers(conn.peer, { type: 'system', text: `${data.name} bergabung` })
        broadcastRoster()
        return
      }
      if (data.type === 'message') {
        const entry = connsRef.current.get(conn.peer)
        const senderName = entry?.name || 'Anonim'
        addMessage({ from: 'peer', senderName, text: data.text, time: data.time })
        broadcastToOthers(conn.peer, { type: 'message', senderName, text: data.text, time: data.time })
      }
    })

    conn.on('close', () => {
      const entry = connsRef.current.get(conn.peer)
      connsRef.current.delete(conn.peer)
      const leaverName = entry?.name || 'Seseorang'
      addSystem(`${leaverName} keluar`)
      broadcastToOthers(conn.peer, { type: 'system', text: `${leaverName} keluar` })
      broadcastRoster()
    })
  }

  function startAsHost(derivedId) {
    const peer = new Peer(derivedId, { config: { iceServers: iceServersRef.current } })
    peerRef.current = peer

    peer.on('open', () => {
      clearTimeout(timeoutRef.current)
      setRole('host')
      setScreen('chat')
      setConnected(true)
      setStatus('terhubung')
      setMembers([{ id: peer.id, name: nameRef.current }])
      addSystem('Kamu membuka room ini. Bagikan kode yang sama ke yang lain untuk bergabung.')
    })

    peer.on('connection', (conn) => {
      if (connsRef.current.size >= MAX_PARTICIPANTS - 1) {
        conn.on('open', () => {
          conn.send({ type: 'full' })
          conn.close()
        })
        return
      }
      setupHostConnection(conn)
    })

    peer.on('error', (err) => {
      console.error(err)
      if (err.type === 'unavailable-id') {
        peer.destroy()
        startAsGuest(derivedId)
      } else {
        clearTimeout(timeoutRef.current)
        setStatus('gagal: ' + err.type)
        setScreen('home')
      }
    })
  }

  // ---------- GUEST ----------
  function startAsGuest(derivedId) {
    const guestPeer = new Peer({ config: { iceServers: iceServersRef.current } })
    peerRef.current = guestPeer

    guestPeer.on('open', () => {
      const conn = guestPeer.connect(derivedId, { reliable: true })
      hostConnRef.current = conn

      conn.on('open', () => {
        clearTimeout(timeoutRef.current)
        setRole('guest')
        setScreen('chat')
        setConnected(true)
        setStatus('terhubung')
        setMembers([{ id: guestPeer.id, name: nameRef.current }])
        conn.send({ type: 'intro', name: nameRef.current })
      })

      conn.on('data', (data) => {
        if (data.type === 'full') {
          setStatus(`room penuh (maks ${MAX_PARTICIPANTS} orang)`)
          setScreen('home')
          conn.close()
          guestPeer.destroy()
          return
        }
        if (data.type === 'roster') {
          setMembers(data.members)
          return
        }
        if (data.type === 'system') {
          addSystem(data.text)
          return
        }
        if (data.type === 'message') {
          addMessage({ from: 'peer', senderName: data.senderName, text: data.text, time: data.time })
        }
      })

      conn.on('close', () => {
        setConnected(false)
        setStatus('terputus (host keluar)')
        addSystem('Koneksi ke room terputus.')
      })

      conn.on('error', (err) => {
        console.error(err)
        clearTimeout(timeoutRef.current)
        setStatus('gagal terhubung ke room')
        setScreen('home')
      })
    })

    guestPeer.on('error', (err) => {
      console.error(err)
      clearTimeout(timeoutRef.current)
      setStatus('gagal: ' + err.type)
      setScreen('home')
    })
  }

  // ---------- MASUK ROOM ----------
  async function handleEnterRoom() {
    const derivedId = sanitizeCode(roomCodeInput)
    if (!derivedId) return

    nameRef.current = name.trim() || 'Anonim'
    setRoomLabel(roomCodeInput.trim())
    setMessages([])
    setMembers([])
    setConnected(false)
    setStatus('menyiapkan koneksi...')
    setScreen('chat')

    timeoutRef.current = setTimeout(() => {
      setStatus('gagal terhubung — coba kode room yang lain (kode ini mungkin masih "kesangkut" dari sesi lama)')
      setScreen('home')
      peerRef.current?.destroy()
    }, 20000)

    iceServersRef.current = await getIceServers()
    setStatus('menghubungkan...')
    startAsHost(derivedId)
  }

  function handleSendMessage() {
    const text = messageInput.trim()
    if (!text || !connected) return
    const time = nowTime()

    if (role === 'host') {
      addMessage({ from: 'me', text, time })
      broadcastToAll({ type: 'message', senderName: nameRef.current, text, time })
    } else if (role === 'guest') {
      addMessage({ from: 'me', text, time })
      hostConnRef.current?.send({ type: 'message', text, time })
    }
    setMessageInput('')
  }

  function handleLeave() {
    clearTimeout(timeoutRef.current)
    hostConnRef.current?.close()
    connsRef.current.forEach(({ conn }) => conn.close())
    connsRef.current.clear()
    peerRef.current?.destroy()
    peerRef.current = null
    hostConnRef.current = null
    setMessages([])
    setMembers([])
    setRole('')
    setStatus('')
    setConnected(false)
    setSidebarOpen(false)
    setScreen('home')
  }

  const myId = peerRef.current?.id
  const participantCount = members.length || 1

  // ---------- HOME SCREEN ----------
  if (screen === 'home') {
    return (
      <div className="app-shell">
        <div className="home-wrap">
          <div className="card">
            <div className="brand">
              <div className="brand-mark" />
              <div className="brand-name">
                MY <span>CHAT</span>
              </div>
            </div>
            <div className="brand-sub">Real-time · P2P · Tanpa Server</div>

            <div className="field">
              <label className="field-label">Nama Panggilan</label>
              <input
                className="input"
                placeholder="mis. Budi"
                value={name}
                onChange={(e) => setName(e.target.value)}
                maxLength={20}
              />
            </div>

            <div className="field">
              <label className="field-label">Kode Room</label>
              <input
                className="input"
                placeholder="mis. rahasia123 atau kata sandi apa saja"
                value={roomCodeInput}
                onChange={(e) => setRoomCodeInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleEnterRoom()}
              />
            </div>

            <p className="hint">
              Maks {MAX_PARTICIPANTS} orang per ruang. Semua yang ketik kode sama akan saling terhubung
              langsung antar browser (P2P) — kode dan pesan tidak pernah disimpan di server manapun.
            </p>

            <button className="btn btn-primary" onClick={handleEnterRoom} disabled={!roomCodeInput.trim()}>
              Masuk Room
            </button>

            {status && <p className="status error-text">{status}</p>}
          </div>
        </div>
      </div>
    )
  }

  // ---------- CHAT SCREEN ----------
  return (
    <div className="app-shell">
      <div className="chat-shell">
        <div className={`sidebar-backdrop ${sidebarOpen ? 'show' : ''}`} onClick={() => setSidebarOpen(false)} />

        <div className={`sidebar ${sidebarOpen ? 'open' : ''}`}>
          <div className="brand">
            <div className="brand-mark" />
            <div className="brand-name">
              MY <span>CHAT</span>
            </div>
          </div>

          <div className="side-block">
            <div className="side-label">Kode Ruang</div>
            <div className="room-code-display">{roomLabel}</div>
            <div className={`status-line ${connected ? '' : 'pending'}`}>
              <span className="dot" />
              {status}
            </div>
          </div>

          <div className="side-block" style={{ flex: 1, display: 'flex', flexDirection: 'column', minHeight: 0 }}>
            <div className="side-label">
              Peserta ({participantCount}/{MAX_PARTICIPANTS})
            </div>
            <div className="member-list">
              {members.map((m) => (
                <div className="member-row" key={m.id}>
                  <span className="member-dot" />
                  <span>{m.name}</span>
                  {m.id === myId && <span className="member-you">KAMU</span>}
                </div>
              ))}
            </div>
          </div>

          <button className="leave-btn" onClick={handleLeave}>
            Keluar Room
          </button>
        </div>

        <div className="chat-main">
          <div className="chat-header">
            <button className="hamburger-btn" onClick={() => setSidebarOpen(true)} aria-label="Buka menu">
              ☰
            </button>
            <div className="chat-header-info">
              <div className="chat-header-room">
                ruang: <b>{roomLabel}</b> · {participantCount}/{MAX_PARTICIPANTS} peserta
              </div>
            </div>
          </div>

          <div className="messages">
            {messages.length === 0 && (
              <div className="msg-empty">
                <div className="msg-empty-icon" />— Awal percakapan —
              </div>
            )}
            {messages.map((m, i) => {
              if (m.from === 'system') {
                return (
                  <div key={i} className="bubble-system">
                    {m.text}
                  </div>
                )
              }
              return (
                <div key={i} className={m.from === 'me' ? 'bubble bubble-me' : 'bubble bubble-peer'}>
                  {m.from === 'peer' && <div className="bubble-sender">{m.senderName}</div>}
                  <div>{m.text}</div>
                  {m.time && <div className="bubble-time">{m.time}</div>}
                </div>
              )
            })}
            <div ref={chatEndRef} />
          </div>

          <div className="chat-input-bar">
            <input
              className="input"
              placeholder={connected ? 'Tulis pesan...' : 'Menghubungkan...'}
              value={messageInput}
              onChange={(e) => setMessageInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
              disabled={!connected}
            />
            <button className="send-btn" onClick={handleSendMessage} disabled={!connected}>
              ➤
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
